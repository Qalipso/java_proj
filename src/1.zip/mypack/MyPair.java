package mypack;
public class MyPair<A, B> {
    public A str;
    public B strnum;

    public MyPair(A first, B second) {
        super();
        this.str = first;
        this.strnum = second;
    }

    /*public A getFirst() {
        return first;
    }

    public void setFirst(A first) {
        this.first = first;
    }

    public B getSecond() {
        return second;
    }

    public void setSecond(B second) {
        this.second = second;
    }*/
}