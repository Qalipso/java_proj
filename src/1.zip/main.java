public class main {
    public static void main(String[] args) {
        mypack.MainWindow w = new mypack.MainWindow();
        w.setVisible(true);
    }

}
